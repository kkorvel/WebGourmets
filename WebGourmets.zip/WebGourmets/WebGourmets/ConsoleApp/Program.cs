﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading.Tasks;
using DAL;
using DAL.Repositories;
using Domain;
using System.Xml.Linq;

namespace ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {

            //using (var ctx = new AppDbContext())
            //{
            //    //var personRepository = new UserRepository(dbContext: ctx);

            //foreach (var person in personRepository
            //    .GetOrderedRecords(recordLimit: 1))
            //{
            //    Console.WriteLine(value: $"{person.UserId} - {person.FirstLastName}");
            //    Console.WriteLine(person.Username);

            //}
            //		ConnectionString	"Data Source=(LocalDb)\\MSSQLLocalDB;\r\n         Initial Catalog=WebGourmets;\r\n         Integrated Security=True;\r\n         MultipleActiveResultSets=True"	string


            //variant 1 Poska


            //using (AppDbContext db = new AppDbContext())
            //{
            //    Console.WriteLine(db.Component.Count());
            //    return;
            //    Component compKartul = new Component()
            //    {
            //        ComponentName = "Kartul"

            //    };
            //    Component compKapsas = new Component()
            //    {
            //        ComponentName = "Kapsas"

            //    };
            //    db.Component.Add(compKartul);
            //    db.Component.Add(compKapsas);
            //    db.SaveChanges();

            //}
            /*
            using (var context = new AppDbContext())
            {
                var retsept = new Recipe()
                {
                    RecipeId = 0,
                    RecipeCategory = 0,
                    RecipeName = "Manhattani toorjuustukook",
                    PortionAmount = 1,
                    RecipeDescription = "Kook on kolmekihiline - all on Digestive-küpsistest põhi, siis toorjuustukiht ja hapukoorekate. Kui soovid uhkemat toorjuustukooki, siis tee täidise osa topelt - põhja ja hapukoorekatte kogused jäävad samaks.Vahendid küpsetamiseks ning ilusaks serveerimiseks leiate kauplusest Apelsin(Tallinnas Järve ja Rocca al Mare keskuses, Rakveres Vaala keskuses). ",
                    Instructions = new XCData(
@"8 Digestive-küpsist
50 g sulatatud võid
Täidis:
75 g suhkrut
2 muna
400 g Piimameister OTTO toorjuustu
0.5 tl vanilliekstrakti või 1 tl vanillisuhkrut
Kate:
250 g hapukoort
2 sl suhkrut
0.5 tl vanilliekstrakti või 1 tl kvaliteetset vanillisuhkrut "),
                    OverallRating = null,
                    NumberOfAssessors = 0,
                    UserId = 0
                };

                context.Recipe.Add(entity: retsept);

                context.SaveChanges();
                //Console.WriteLine("Stuff added!");
            }
            */
            //variant 2 Käver
            using (var ctx = new AppDbContext())
            {
                return;
                ctx.MeasuringUnit.Add(entity: new MeasuringUnit
                {
                    MeasuringUnitName = "ml"

                });
                ctx.SaveChanges();
                
            }

            }
            //Console.Write(value: "Press enter to exit!");
            //Console.ReadLine();
        }
    }


