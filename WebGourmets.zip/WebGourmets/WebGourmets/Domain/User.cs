﻿using Domain.Enums;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain
{
	public class User
	{
        [Display(Name = "User Id")]
        public int UserId { get; set; }

        [MaxLength(35)]
        [Required]
        [Display(Name = "Username")]
        public string Username { get; set; }

        [MaxLength(50)]
        [Required]
        [DataType(DataType.Password)]
        public string Password { get; set; }
        [Display(Name = "First name")]
        public string FirstName { get; set; }

        [Display(Name = "Last name")]
        public string LastName { get; set; }

        [Display(Name = "User Type")]
        public UserType UserType { get; set; }

        public virtual List<UserNote> UserNote { get; set; }
        public virtual List<FoodComment> FoodComment { get; set; }
        public virtual List<Recipe> Recipe { get; set; }




        #region NotMapped
        public string FirstLastName => ($"{FirstName} {LastName}").Trim();
        public string LastFirstName => ($"{LastName} {FirstName}").Trim();
        #endregion

    }
}
