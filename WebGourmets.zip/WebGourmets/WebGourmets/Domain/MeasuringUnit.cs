﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain
{


	public class MeasuringUnit
    {
        [Display(Name = "Measuring Unit Id")]
        public int MeasuringUnitId { get; set; }

        [Display(Name = "Measuring unit name")]
        [MaxLength(length: 120), MinLength(length: 1)]
        public string MeasuringUnitName { get; set; }

        public virtual List<RecipeComponent> RecipeComponent { get; set; }

    }
}
