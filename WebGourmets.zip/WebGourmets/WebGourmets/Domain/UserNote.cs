﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain
{
	public class UserNote
    {
        [Display(Name = "UserNote Id")]
        public int UserNoteId { get; set; }
        [Display(Name = "UserId")]
        public int? UserId { get; set; } //!! nullable (?)
        [Display(Name = "RecipeId")]
        public int? RecipeId { get; set; } //!! nullable (?)
        [Display(Name = "Note")]
        public string Note { get; set; }
        [Display(Name = "Date")]
        public DateTime Date { get; set; }
        [ForeignKey("RecipeId")]
        public virtual Recipe Recipe { get; set; }
        [ForeignKey("UserId")]
        public virtual User User { get; set; }


    }
}
