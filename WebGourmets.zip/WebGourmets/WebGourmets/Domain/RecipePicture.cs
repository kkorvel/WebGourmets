﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain
{
    public class RecipePicture
    {
        public int RecipePictureId { get; set; }
        public int RecipeId { get; set; }
        public int PictureId { get; set; }

        public virtual Recipe Recipe { get; set; }
        public virtual Picture Picture { get; set; }
       
    }
}
