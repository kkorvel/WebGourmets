﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain
{
   public class FoodComment
    {
        [Display(Name = "Food Comment Id")]
        public int FoodCommentId { get; set; }

        [Display(Name = "Food Id")]
        public int FoodId { get; set; }

        [Display(Name = "User Id")]
        public int UserId { get; set; }

        [Required]
        [MaxLength(length: 120)]
        [Display(Name = "Comment")]
        public string Comment { get; set; }

        [Display(Name = "Time")]
        public DateTime Time { get; set; }

        public virtual Recipe Recipe { get; set; }

        public virtual User User { get; set; }
    }
}
