﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain
{
    public class RecipeComponent
    {
        [Display(Name = "Recipe component id")]
        public int RecipeComponentId { get; set; }

        [Display(Name = "Recipe Id")]
        public int RecipeId { get; set; }

        [Display(Name = "Component name")]
        [MaxLength(length: 120), MinLength(length: 1)]
        public string ComponentName { get; set; }

        [Display(Name = "Component Id")]
        public int ComponentId { get; set; }

        [Display(Name = "Component amount")]
        public double ComponentAmount { get; set; }

        [Display(Name = "Measuring unit name")]
        public int MeasuringUnitId { get; set; }

        public virtual MeasuringUnit MeasuringUnit { get; set; }

        public virtual Recipe Recipe { get; set; }

        public virtual Component Component { get; set; }


  
    }
}
