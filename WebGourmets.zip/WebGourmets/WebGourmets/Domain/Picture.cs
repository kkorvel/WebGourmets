﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain
{
    public class Picture
    {
        public int PictureId { get; set; }
        [Display(Name = "Picture path")]
        public string PicturePath { get; set; }

        public byte[] test { get; set; }

        public string base64string { get; set; }
  
        public virtual List<RecipePicture> RecipePicture { get; set; }
 
       public Picture()
       {
           this.RecipePicture = new List<RecipePicture>();
       } 
   
    }
}
