﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain
{
    public class FoodCategory
    {
        [Display(Name = "Food Category Id")]
        public int FoodCategoryId { get; set; }
        //[Required]

        [Display(Name = "Category name")]
        [MaxLength(length: 120), MinLength(length: 1)]
        public string FoodCategoryName { get; set; }

        //public virtual List<Recipe> Recipe{ get; set; }
        public virtual Recipe Recipe { set; get; }



    }
}
