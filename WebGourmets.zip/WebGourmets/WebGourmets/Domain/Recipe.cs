﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;


namespace Domain
{
    public class Recipe
    {
        public int RecipeId { get; set; }

        // public string FoodCategory { get; set; }
        [Required]
        [Display(Name = "Name of recipe")]
        [MaxLength(length: 120), MinLength(length: 1)]
        public string RecipeName { get; set; }

        [Display(Name = "Amount of portion")]
        public int? PortionAmount { get; set; }

        [Required]
        [Display(Name = "Description")]
        [MaxLength(length: 1500), MinLength(length: 1)]
        public string RecipeDescription { get; set; }

        public int RecipeComponentId { get; set; }

        [Required]
        [Display(Name = "Instruction")]
        [MaxLength(length: 1500), MinLength(length: 1)]
        public string Instructions { get; set; }

        [Display(Name = "Rating")]
        public int? OverallRating { get; set; }

        [Display(Name = "Number of raters")]
        public int? NumberOfAssessors { get; set; }

        [Display(Name = "Picture Content")]
        public byte[] Content { get; set; }

        public string ContentType { get; set; }

        public string ComponentName { get; set; }

        //see peab olema ikka
        [ForeignKey("FoodCategory")]
        public int FoodCategoryId { get; set; }


        // public int? UserId { get; set; }
        public virtual Component Component { get; set; }
        //public virtual List<Component> Component { get; set; }
        public virtual User User { get; set; }

        public virtual FoodCategory FoodCategory { get; set; }

        public virtual RecipePicture RecipePicture { get; set; }

        public virtual ICollection<FoodCategory> FoodCategories { get; set; }

        public virtual ICollection<RecipePicture> RecipePictures { get; set; }

        public virtual List<UserNote> UserNote { get; set; }

        public virtual List<FoodComment> FoodComment { get; set; }

        public virtual List<RecipeComponent> RecipeComponent { get; set; }

        public virtual List<Component> Components { get; set; }





        /*
                public Recipe()
                {
                    this.RecipePictures = new List<RecipePicture>();
                }
                */

    }
}
