﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Domain;

namespace Domain
{
    public class Component
    {
        [Display(Name = "Component Id")]
        public int ComponentId { get; set; }

        [Required]
        [MaxLength(length: 120), MinLength(length: 1)]
        [Display(Name = "Component name")]
        public string ComponentName { get; set; }

        public virtual List<RecipeComponent> RecipeComponent  { get; set; }
    }
}
