﻿using Domain;
using Domain.Enums;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace DAL.Helpers
{
    public class DbInitializer : DropCreateDatabaseIfModelChanges<AppDbContext>
    {
        protected override void Seed(AppDbContext context)
        {
            //base.Seed(context: context);
            var p1 = new User()
            {
      
               FirstName = "Assa",
               LastName = "Mait",
               Username = "assamait1234",
               Password = "test123",
               UserType = UserType.Account
            };


            var gramm = new MeasuringUnit()
            {
                MeasuringUnitName = "g"
            };
            var teelusikas = new MeasuringUnit()
            {
 
                MeasuringUnitName = "tl"
            };
            var supilusikas = new MeasuringUnit()
            {

                MeasuringUnitName = "sl"
            };
            var milliliiter = new MeasuringUnit()
            {

                MeasuringUnitName = "ml"
            };
            //mitu tükki
            var tukk = new MeasuringUnit()
            {

                MeasuringUnitName = "tk"
            };


            //////////
            //komponendid
            var voi = new Component()
            {

                ComponentName = "Või"
            };
            var suhkur = new Component()
            {

                ComponentName = "suhkur"
            };
            var sool = new Component()
            {

                ComponentName = "sool"
            };
            var muna = new Component()
            {

                ComponentName = "muna"
            };
            var juust = new Component()
            {

                ComponentName = "juust"
            };
            var hapukoor = new Component()
            {
    
                ComponentName = "hapukoor"
            };
            var vanilliekstrakt = new Component()
            {
     
                ComponentName = "vanilliekstrakt"
            };
            var digestive_cookie = new Component()
            {
             
                ComponentName = "Digestive küpsis"
            };
           
            ///
            //retsepti komponendid



            var koogid = new FoodCategory()
            {
            
                FoodCategoryName = "koogid"
            };

            var recipeComponent = new RecipeComponent()
            {
                RecipeComponentId = 1,
                RecipeId = 1,
                ComponentId = 1,
                MeasuringUnitId = 1,
                ComponentAmount = 222,
                

            };

            var recipeComponent2 = new RecipeComponent()
            {
                RecipeComponentId = 2,
                RecipeId = 2,
                ComponentId = 4,
                MeasuringUnitId = 5,
                ComponentAmount = 5,


            };



            var retsept = new Recipe()
            {

                
                RecipeName = "Manhattani toorjuustukook",
                RecipeDescription = "Kook on kolmekihiline - all on Digestive-küpsistest põhi, siis toorjuustukiht ja hapukoorekate. Kui soovid uhkemat toorjuustukooki, siis tee täidise osa topelt - põhja ja hapukoorekatte kogused jäävad samaks.Vahendid küpsetamiseks ning ilusaks serveerimiseks leiate kauplusest Apelsin(Tallinnas Järve ja Rocca al Mare keskuses, Rakveres Vaala keskuses). ",
                Instructions = (
@"8 Digestive-küpsist
50 g sulatatud võid
Täidis:
75 g suhkrut
2 muna
400 g Piimameister OTTO toorjuustu
0.5 tl vanilliekstrakti või 1 tl vanillisuhkrut
Kate:
250 g hapukoort
2 sl suhkrut
0.5 tl vanilliekstrakti või 1 tl kvaliteetset vanillisuhkrut "),
             


            };

            var retsept2 = new Recipe()
            {


                RecipeName = "pannkoogid moosiga",
                RecipeDescription = "ohukesed pannkoogid moosiga ",
                Instructions = (
@"8 Digestive-küpsist
50 g sulatatud võid
Täidis:
75 g suhkrut
2 muna
400 g Piimameister OTTO toorjuustu
0.5 tl vanilliekstrakti või 1 tl vanillisuhkrut
Kate:
250 g hapukoort
2 sl suhkrut
0.5 tl vanilliekstrakti või 1 tl kvaliteetset vanillisuhkrut "),



            };
            var komponent = new Component()
            {
                ComponentName = "kalamaksaõli"
            };





            //Console.WriteLine(p1);
            //lisab kasutaja

            context.Users.Add(entity: p1);

            context.MeasuringUnit.Add(entity: gramm);
            context.MeasuringUnit.Add(entity: teelusikas);
            context.MeasuringUnit.Add(entity: supilusikas);
            context.MeasuringUnit.Add(entity: milliliiter);
            context.MeasuringUnit.Add(entity: tukk);

            context.Component.Add(entity: voi);
            context.Component.Add(entity: suhkur);
            context.Component.Add(entity: sool);
            context.Component.Add(entity: muna);
            context.Component.Add(entity: juust);
            context.Component.Add(entity: hapukoor);
            context.Component.Add(entity: vanilliekstrakt);
            context.Component.Add(entity: digestive_cookie);
            context.Component.Add(entity: komponent);

        

            context.FoodCategory.Add(entity: koogid);

            context.Recipe.Add(entity: retsept);
            context.Recipe.Add(entity: retsept2);

            context.RecipeComponent.Add(entity: recipeComponent);
            context.RecipeComponent.Add(entity: recipeComponent2);
            context.SaveChanges();
            Console.WriteLine("Stuff added!");

        }
    }
}
