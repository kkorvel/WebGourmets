﻿using Domain;
using interfaces;
using Interfaces;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.Repositories
{
    //add interface!
    public class UserRepository : EFRepository<User>, IUserRepository
    {
        public UserRepository(IAppDataContext dbContext) : base(dbContext: dbContext)
        {
        }

        public User FindByName(string name)
        {
            return RepositoryDbSet.Where(user => user.Username.Equals(name)).FirstOrDefault();
        }
      

        public List<User> GetOrderedRecords(int recordLimit, bool orderByFirstName = true)
        {
            var query = RepositoryDbSet.AsQueryable();

            query = orderByFirstName ? query
                .OrderBy(keySelector: a => a.FirstName) : query.OrderBy(keySelector: a => a.LastName);

            switch (recordLimit)
            {
                case 0:
                    break;
                default:
                    query = query.Take(count: recordLimit);
                    break;
            }

            return query.ToList();
        }
    }
}