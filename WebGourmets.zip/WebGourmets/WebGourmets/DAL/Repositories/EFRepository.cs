﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Interfaces;
using System.Data.Entity.Infrastructure;

namespace DAL.Repositories
{
    //add interface!
    public class EFRepository<TEntity> : IRepository<TEntity>
     //siin on piirang kirjas, genericu jaoks (peab olema igaljuhul olema klass)
     where TEntity : class
    {
        protected DbContext RepositoryDbContext;
        protected DbSet<TEntity> RepositoryDbSet;

        public EFRepository(IAppDataContext dbContext)
        {
            RepositoryDbContext = dbContext as DbContext;
            if (RepositoryDbContext == null)
            {
                throw new ArgumentNullException(paramName: nameof(dbContext));
            }
            RepositoryDbSet = RepositoryDbContext.Set<TEntity>();
            if (RepositoryDbSet == null)
            {
                throw new NullReferenceException(message: nameof(RepositoryDbSet));
            }
        }

        public List<TEntity> All
        {
            get
            {
                var resCount = RepositoryDbSet.Count();
                if (resCount < 1500)
                {
                    return RepositoryDbSet.ToList();
                }
                throw new Exception(message: "WTF? To many records in resultset! Please add custom data access methods to repositry!");
            }
        }

        public TEntity Find(int id)
        {
            return RepositoryDbSet.Find(id);
        }

        public void Remove(int id)
        {
            Remove(entity: Find(id: id));
        }

        // Entity Framework Add and Attach and Entity States
        // https://msdn.microsoft.com/en-us/library/jj592676(v=vs.113).aspx

        public void Remove(TEntity entity)
        {
            DbEntityEntry dbEntityEntry = RepositoryDbContext.Entry(entity: entity);
            if (dbEntityEntry.State != EntityState.Deleted)
            {
                dbEntityEntry.State = EntityState.Deleted;
            }
            else
            {
                RepositoryDbSet.Attach(entity: entity);
                RepositoryDbSet.Remove(entity: entity);
            }

        }

        public TEntity Add(TEntity entity)
        {
            DbEntityEntry dbEntityEntry = RepositoryDbContext.Entry(entity: entity);
            if (dbEntityEntry.State != EntityState.Detached)
            {
                dbEntityEntry.State = EntityState.Added;
                return entity;
            }
            return RepositoryDbSet.Add(entity: entity);
        }

        public void Update(TEntity entity)
        {
            DbEntityEntry dbEntityEntry = RepositoryDbContext.Entry(entity: entity);
            if (dbEntityEntry.State == EntityState.Detached)
            {
                RepositoryDbSet.Attach(entity: entity);
            }
            dbEntityEntry.State = EntityState.Modified;
        }

        public int SaveChanges()
        {
            return RepositoryDbContext.SaveChanges();
        }
    }
}
