﻿using Domain;
using interfaces;
using Interfaces;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.Repositories
{
    //add interface!
    public class ComponentRepository : EFRepository<Component>, IComponentRepository
    {
        public ComponentRepository(IAppDataContext dbContext) : base(dbContext: dbContext)
        {

        }
        public Component FindByName(string name)
        {
            return RepositoryDbSet.Where(component => component.ComponentName.Equals(name)).FirstOrDefault();
        }
    }
}

