﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Domain;
using Interfaces;

namespace DAL.Repositories
{
    //add interface!

    public class RecipeRepository : EFRepository<Recipe>, IRecipeRepository
    {
        public RecipeRepository(IAppDataContext dbContext) : base(dbContext: dbContext)
        {
        }
    }
}