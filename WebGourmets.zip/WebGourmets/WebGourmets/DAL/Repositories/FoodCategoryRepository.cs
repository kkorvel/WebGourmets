﻿using Domain;
using interfaces;
using Interfaces;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.Repositories
{
    //add interface!
    public class FoodCategoryRepository : EFRepository<FoodCategory>, IFoodCategoryRepository
    {
        public FoodCategoryRepository(IAppDataContext dbContext) : base(dbContext: dbContext)
        {
   
        }
        public FoodCategory FindByName(string name)
        {
            return RepositoryDbSet.Where(category => category.FoodCategoryName.Equals(name)).FirstOrDefault();
        }

    }
}

