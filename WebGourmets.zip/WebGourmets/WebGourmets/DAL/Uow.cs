﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL.Repositories;
using Domain;
using Interfaces;
using interfaces;

namespace DAL
{
    public class Uow : IUow
    {
        private readonly IAppDataContext _appDataContext;
        private readonly IRepositoryProvider _repositoryProvider;
        public Uow(IAppDataContext appDataContext, IRepositoryProvider repositoryProvider)
        {
            _appDataContext = appDataContext;
            _repositoryProvider = repositoryProvider;
        }

        // standard repos, based on IRepository/EFRepository. just update IUow and Uow
      //  public IRepository<Recipe> Recipes => GetStandardRepo<Recipe>();
      //  public IRepository<Course> Courses => GetStandardRepo<Course>();

        // list all your custom repos and their creation mechanism in dictionary - in Helpers/EFRepositoryFactories
        // add declarations in IUow also!
        public IRecipeRepository Recipes => GetCustomRepo<IRecipeRepository>();
        public IRecipeComponentRepository RecipeComponent => GetCustomRepo<IRecipeComponentRepository>();
        public IComponentRepository Components => GetCustomRepo<IComponentRepository>();
        public IMeasuringUnitRepository MeasuringUnit => GetCustomRepo<IMeasuringUnitRepository>();

        public IFoodCategoryRepository FoodCategories => GetCustomRepo<IFoodCategoryRepository>();


        private IRepository<TEntity> GetStandardRepo<TEntity>() where TEntity : class
        {
            return _repositoryProvider.GetStandardRepo<TEntity>();
        }

        private TRepoInterface GetCustomRepo<TRepoInterface>()
        {
            return _repositoryProvider.GetCustomRepo<TRepoInterface>();
        }

        public int SaveChanges()
        {
            return ((DbContext)_appDataContext).SaveChanges();
        }
    }
}
