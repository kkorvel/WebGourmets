﻿using DAL.Helpers;
using Domain;
using Interfaces;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.Entity;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class AppDbContext : DbContext, IAppDataContext
    {
        public DbSet<Domain.Component> Component { get; set; }
        public DbSet<FoodCategory> FoodCategory { get; set; }
        public DbSet<FoodComment> FoodComment { get; set; }
        public DbSet<MeasuringUnit> MeasuringUnit { get; set; }
        public DbSet<Picture> Picture { get; set; }
        public DbSet<Recipe> Recipe { get; set; }
        public DbSet<RecipeComponent> RecipeComponent { get; set; }
        public DbSet<RecipePicture> RecipePicture { get; set; }

        public DbSet<UserNote> UserNote { get; set; }
        public AppDbContext() : base(nameOrConnectionString: "name=AppDbConnectionString")
        {

            Database.SetInitializer(
                strategy: new DbInitializer());
#if DEBUG
            Database.Log = s => Trace.Write(
                value: s.StartsWith(value: "SELECT") ? s + "\n\n" : "");
#else
            Database.Log = s => Console.Write(
                value: s.StartsWith(value: "SELECT") ? s+"\n\n" : "" );
#endif
        }

        public System.Data.Entity.DbSet<Domain.User> Users { get; set; }

    }
}

