﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ClientWeb.Service.Models
{
    public class RecipeDTO
    {

        public int RecipeId { get; set; }
        public string RecipeName { get; set; }
        public int? PortionAmount { get; set; }
        public string RecipeDescription { get; set; }
        public string Instructions { get; set; }
       // public List<RecipeComponentsDTO> Components { get; set; }

        public string FoodCategory { get; set; }
        //public string Components { get; set; }
        //public string RecipeComponents { get; set; }
        //public string RecipeInstruction { get; set; }
    }
}