﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;

namespace ClientWeb.Service
{
    public class BaseService
    {
        protected HttpClient client;

        public BaseService(string uri)
        {
            client = new HttpClient();
            //client.DefaultRequestHeaders.Add()
            client.BaseAddress = new Uri(uri);
            client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

        }

        protected async Task<T> GetData<T>(string urlPath)
        {
            var responseMessage = await client.GetAsync(urlPath);
            responseMessage.EnsureSuccessStatusCode();
            T ret = await responseMessage.Content
                .ReadAsAsync<T>();

            return ret;
        }

        protected async Task<T> PostData<T>(string urlPath, T obj)
        {
            var response = await client.PostAsJsonAsync<T>(urlPath, obj);
            return await response.Content.ReadAsAsync<T>();
        }
    }
}