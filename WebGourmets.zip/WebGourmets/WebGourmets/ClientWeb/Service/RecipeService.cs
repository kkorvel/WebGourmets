﻿using ClientWeb.Service.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace ClientWeb.Service
{
    public class RecipeRESTService : BaseService
    {
        public RecipeRESTService() : base("http://localhost:49914/api/recipe/")
        {

        }

        public async Task<List<RecipeDTO>> GetAll()
        {
            return await base.GetData<List<RecipeDTO>>("");
        }
    }
}