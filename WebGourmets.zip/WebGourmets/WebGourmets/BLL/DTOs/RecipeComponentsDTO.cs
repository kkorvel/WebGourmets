﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.DTOs
{
    public class RecipeComponentsDTO
    {
        public int RecipeComponentId { get; set; }
        public int RecipeId { get; set; }
        //oluline
        public string ComponentName { get; set; }


        public int ComponentId { get; set; }
        public double ComponentAmount { get; set; }
        public int MeasuringUnitId { get; set; }
        //oluline
        public string MeasuringUnitName { get; set; }
        //public int FoodCategoryId { get; set; }
        public MeasuringUnitDTO MeasuringUnit   { get; set; }
        public ComponentDTO Component { get; set; }

       // public List<ComponentDTO> Components { get; set; }

    }
}
