﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.DTOs
{
   public class MeasuringUnitDTO
    {
        public int MeasuringUnitId { get; set; }
        public string MeasuringUnitName { get; set; }
    }
}
