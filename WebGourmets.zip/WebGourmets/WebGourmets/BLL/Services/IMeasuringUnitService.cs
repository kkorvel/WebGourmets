﻿using BLL.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.Services
{
    public interface IMeasuringUnitService : IService
    {
        List<DTOs.MeasuringUnitDTO> GetAll();

        MeasuringUnitDTO GetById(int id);
        bool Update(MeasuringUnitDTO measuringunitDto);

        List<MeasuringUnitDTO> GetMeasuringUnitByName(string name);
        MeasuringUnitDTO AddNewMeasuringUnit(MeasuringUnitDTO measuringunitDto);
        bool DeleteById(int id);
    }
}
