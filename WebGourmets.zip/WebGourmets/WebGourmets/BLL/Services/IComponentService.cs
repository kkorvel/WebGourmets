﻿using BLL.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.Services
{
    public interface IComponentService : IService
    {

        List<DTOs.ComponentDTO> GetAll();



        List<ComponentDTO> GetComponentByName(string name);


        ComponentDTO GetById(int id);


        bool Update(ComponentDTO componentDTO);

        ComponentDTO AddNewComponent(ComponentDTO componentDto);
        bool DeleteById(int id);
    }
}
