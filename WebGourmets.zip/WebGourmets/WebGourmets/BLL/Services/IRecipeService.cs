﻿using BLL.DTOs;
using Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.Services
{
    public interface IRecipeService : IService
    {
        List<DTOs.RecipeDTO> GetAll();

      

        List<RecipeDTO> GetRecipeByName(string name);

        List<RecipeDTO> GetRecipeByIngredientName(string ingredient);

        RecipeDTO GetById(int id);


        bool Update(RecipeDTO recipeDto);

        RecipeDTO AddNewRecipe(RecipeDTO recipeDto);
        bool DeleteById(int id);

    }
}
