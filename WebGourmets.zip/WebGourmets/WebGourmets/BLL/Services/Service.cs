﻿using System;
using System.Collections.Generic;

using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Domain;
using System.ComponentModel.DataAnnotations;
namespace BLL.Services
{
    public class Service : IService
    {
        public string LastErrorMessage { get; private set; }


        public bool ValidateDomainModel(Object u)
        {
            var context = new ValidationContext(instance: u, serviceProvider: null, items: null);
            var validationResults = new List<ValidationResult>();

            bool isValid = Validator
                .TryValidateObject(
                    instance: u,
                    validationContext: context,
                    validationResults: validationResults,
                    validateAllProperties: true);

            StringBuilder builder = new StringBuilder();
            foreach (var item in validationResults)
            {
                builder.Append(value: item.ErrorMessage);
            }
            LastErrorMessage = builder.ToString();

            return isValid;
        }
    }
}
