﻿
using BLL.DTOs;
using BLL.Factories;
using Domain;
using interfaces;
using Interfaces;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
namespace BLL.Services
{
    public class RecipeComponentsService : IRecipeComponentsService
    {


        private readonly IRecipeComponentRepository _recipecomponentRepository;
        private readonly IRecipeRepository _recipeRepository;
        private readonly IComponentRepository _componentRepository;
        private readonly IMeasuringUnitRepository _measuringUnitRepository;

        private readonly RecipeComponentFactory _recipecomponentsFactory;
        //private readonly ComponentsFactory _componentsFactory;

        public RecipeComponentsService(IRecipeComponentRepository recipecomponentRepository,
            IRecipeRepository recipeRepository, IComponentRepository componentRepository, IMeasuringUnitRepository measuringUnitRepository)
        {
            _recipeRepository = recipeRepository;
            _componentRepository = componentRepository;
            _recipecomponentRepository = recipecomponentRepository;
            _measuringUnitRepository = measuringUnitRepository;

            _recipecomponentsFactory = new RecipeComponentFactory();

        }

        public RecipeComponentsDTO AddNewRecipeComponets(RecipeComponentsDTO recipeComponentDto)
        {
            // RecipeComponentsDTO >> RecipeComponents
            RecipeComponent recipeComponent = _recipecomponentsFactory.Create(recipeComponentDto);
            // kontrolli, et viidatud ID-dega asjad eksisteerivad db-s
            Recipe recipe = _recipeRepository.Find(recipeComponent.RecipeId);
            if(recipe == null)
            {
                return null;
            }
            //1
            Component component = _componentRepository.Find(recipeComponent.ComponentId);
            //2
            if (component == null)
            {
                return null;
            }
            MeasuringUnit mu = _measuringUnitRepository.Find(recipeComponent.MeasuringUnitId);
            if (mu == null)
            {
                return null;
            }
            //kui ei, return bad request controlleris
            
            // salvesta db-sse
            RecipeComponent saved = _recipecomponentRepository.Add(recipeComponent);
            _recipecomponentRepository.SaveChanges();
            //tagasta salvestatud asi ( factory-s RecipeComponents >> RecipeComponentsDTO

            return _recipecomponentsFactory.Create(saved);
        }

        public List<RecipeComponentsDTO> GetAll()
        {
            return _recipecomponentRepository
                .All
                .Select(selector: x => _recipecomponentsFactory.Create(x))
                .ToList();
        }
    }
}
