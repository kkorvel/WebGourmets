﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BLL.DTOs;
using BLL.Services;
using BLL.Factories;
using Domain;
using Interfaces;
using System.Globalization;

namespace BLL.Services
{
    public class RecipeService : Service, IRecipeService
    {

        private readonly IRecipeRepository _recipeRepository;
        private readonly RecipeFactory _recipeFactory;
        private readonly ComponentsFactory _componentsFactory;

        public RecipeService(IRecipeRepository recipeRepository)
        {
            _recipeRepository = recipeRepository;
            _recipeFactory = new RecipeFactory();
            _componentsFactory = new ComponentsFactory();
        }
        


        private readonly IUow _uow;

        public RecipeService(IUow uow)
        {
            this._uow = uow;
        }
        public List<RecipeDTO> GetAll()
        {
            /*   var ret = _uow.Recipes.All.Select(x => new RecipeDTO() {
                   RecipeId = x.RecipeId,
                   RecipeName = x.RecipeName,
                   PortionAmount = x.PortionAmount,
                   FoodCategory = x.FoodCategory.FoodCategoryName,
                   Instructions = x.Instructions,
                   RecipeDescription = x.RecipeDescription,
                   Components = _uow.RecipeComponent.All.Select(y => new RecipeComponentsDTO()
                   {
                       RecipeComponentId = y.RecipeComponentId,
                       RecipeId = y.RecipeId,
                       ComponentId = y.ComponentId,
                       ComponentAmount = y.ComponentAmount,
                       MeasuringUnitId = y.MeasuringUnitId,
                       //nimed!
                       Component = ComponentsFactory.Create(_uow.Components.Find(y.ComponentId)),
                       MeasuringUnit = MeasuringUni
                       tFactory.Create(_uow.MeasuringUnit.Find(y.MeasuringUnitId))


                   }).Where(y => y.RecipeId == x.RecipeId).ToList()
               }).ToList();

               return ret;*/




            //return _recipeRepository
            //.All
            //.Select(selector: x => _recipeFactory.Create(recipe: x))

            //.ToList();

            return _recipeRepository.All.Select(selector: x => _recipeFactory.Create(recipe: x)).ToList();
          
           

        }
        //find recipe by id
        public RecipeDTO GetById(int id)
        {
            var recipe = _recipeRepository.Find(id: id);
            return _recipeFactory.Create(recipe: recipe);
        }

        public List<RecipeDTO> GetRecipeByName(string name)
        {
            return _recipeRepository
            .All
            .Where(p =>CultureInfo.CurrentCulture.CompareInfo.IndexOf(p.RecipeName, name, CompareOptions.IgnoreCase) >= 0)
            .Select(selector: x => _recipeFactory.Create(recipe: x))
            .ToList();
        }

        public List<RecipeDTO> GetRecipeByIngredientName(string name)
        {
            /*

                       var Components = recipe.RecipeComponent.Select(x => new RecipeComponentsDTO
                        {
                            ComponentName = x.Component.ComponentName,
                        }).ToList();


                        */
            //  return _recipeRepository.All.Where(p => CultureInfo.CurrentCulture.CompareInfo.IndexOf(p.RecipeName, name, CompareOptions.IgnoreCase) >= 0).Select(selector: x => _recipeFactory.Create(recipe: x)).ToList();


            var asd =
                _recipeRepository.All
                //.Where(p => p.RecipeId == 1)
                .Where(p => p.RecipeComponent.Count != 0)
                //.Where(p => p.RecipeComponent[p.RecipeComponentId].Component.ComponentName == "muna")
                .Where(p => CultureInfo.CurrentCulture.CompareInfo.IndexOf(p.RecipeComponent[p.RecipeComponentId].Component.ComponentName, name, CompareOptions.IgnoreCase) >= 0)
                .Select(selector: x => _recipeFactory.Create(recipe: x)).ToList();
            Console.WriteLine(asd);
            return asd;
        }   

        //add a new recipe

        public RecipeDTO AddNewRecipe(RecipeDTO recipeDto)
        {

            Recipe domain = _recipeFactory.Create(recipeDto: recipeDto);

            if (!ValidateDomainModel(u: domain))
            {
                return null;
            }

            var ret = _recipeRepository.Add(entity: domain);
            _recipeRepository.SaveChanges();

            return _recipeFactory.Create(recipe: ret);
        }
        //update a recipe
        public bool Update(RecipeDTO recipeDto)
        {
            Recipe newDomain = _recipeFactory.Create(recipeDto: recipeDto);
            Recipe domain = _recipeRepository.Find(id: recipeDto.RecipeId);
            
            domain.RecipeName = newDomain.RecipeName;
            domain.RecipeDescription = newDomain.RecipeDescription;

            _recipeRepository.Update(entity: domain);
            _recipeRepository.SaveChanges();

            return true;
        }
        //delete a recipe
        public bool DeleteRecipeById(int id)
        {
            var ret = GetById(id: id);
            if (ret == null)
            {
                return false;
            }
            _recipeRepository.Remove(id: id);
            _recipeRepository.SaveChanges();
            return true;
        }

        public bool DeleteById(int id)
        {
            var ret = GetById(id: id);
            if (ret == null)
            {
                return false;
            }
            _recipeRepository.Remove(id: id);
            _recipeRepository.SaveChanges();
            return true;
        }

    }
    }

