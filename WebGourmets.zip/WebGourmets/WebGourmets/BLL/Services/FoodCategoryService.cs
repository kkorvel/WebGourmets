﻿using BLL.DTOs;
using BLL.Factories;
using Domain;
using interfaces;
using Interfaces;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.Services
{
    public class FoodCategoryService : Service, IFoodCategoryService
    {

        private readonly IFoodCategoryRepository _foodCategoryRepository;
        private readonly FoodCategoryFactory _foodCategoryFactory;

        public FoodCategoryService(IFoodCategoryRepository foodCategoryRepository)
        {
            _foodCategoryRepository = foodCategoryRepository;
            _foodCategoryFactory = new FoodCategoryFactory();
        }

        private readonly IUow _uow;

        public FoodCategoryService(IUow uow)
        {
            this._uow = uow;
        }

        public List<FoodCategoryDTO> GetAll()
        {
            return _foodCategoryRepository
            .All
            .Select(selector: x => _foodCategoryFactory.Create(foodCategory: x))
            .ToList();
        }

        public FoodCategoryDTO GetById(int id)
        {
            var foodCategory = _foodCategoryRepository.Find(id: id);
            return _foodCategoryFactory.Create(foodCategory: foodCategory);
        }

        public List<FoodCategoryDTO> GetFoodCategoryByName(string name)
        {
            return _foodCategoryRepository
            .All
            .Where(p => CultureInfo.CurrentCulture.CompareInfo.IndexOf(p.FoodCategoryName, name, CompareOptions.IgnoreCase) >= 0)
            .Select(selector: x => _foodCategoryFactory.Create(foodCategory: x))
            .ToList();
        }

        public bool Update(FoodCategoryDTO foodCategoryDto)
        {
            FoodCategory newDomain = _foodCategoryFactory.Create(foodCategoryDTO: foodCategoryDto);
            FoodCategory domain = _foodCategoryRepository.Find(id: foodCategoryDto.FoodCategoryId);

            domain.FoodCategoryName = newDomain.FoodCategoryName;


            _foodCategoryRepository.Update(entity: domain);
            _foodCategoryRepository.SaveChanges();

            return true;
        }

        public FoodCategoryDTO AddNewFoodCategory(FoodCategoryDTO foodCategoryDto)
        {
            FoodCategory domain = _foodCategoryFactory.Create(foodCategoryDTO: foodCategoryDto);

            if (!ValidateDomainModel(u: domain))
            {
                return null;
            }

            var ret = _foodCategoryRepository.Add(entity: domain);
            _foodCategoryRepository.SaveChanges();

            return _foodCategoryFactory.Create(foodCategory: ret);
        }

        public bool DeleteById(int id)
        {
            var ret = GetById(id: id);
            if (ret == null)
            {
                return false;
            }
            _foodCategoryRepository.Remove(id: id);
            _foodCategoryRepository.SaveChanges();
            return true;
        }
    }
}
