﻿using BLL.DTOs;
using BLL.Factories;
using Domain;
using interfaces;
using Interfaces;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.Services
{
    public class MeasuringUnitService : Service, IMeasuringUnitService
    {
        private readonly IMeasuringUnitRepository _measuringUnitRepository;
        private readonly MeasuringUnitFactory _measuringUnitFactory;

        public MeasuringUnitService(IMeasuringUnitRepository measuringUnitRepository)
        {
            _measuringUnitRepository = measuringUnitRepository;
            _measuringUnitFactory = new MeasuringUnitFactory();
        }

        private readonly IUow _uow;

        public MeasuringUnitService(IUow uow)
        {
            this._uow = uow;
        }
        public List<MeasuringUnitDTO> GetAll()
        {
            return _measuringUnitRepository
            .All
            .Select(selector: x => _measuringUnitFactory.Create(measuringUnit: x))
            .ToList();

        }
        public List<MeasuringUnitDTO> GetMeasuringUnitByName(string name)
        {
            return _measuringUnitRepository
            .All
            .Where(p => CultureInfo.CurrentCulture.CompareInfo.IndexOf(p.MeasuringUnitName, name, CompareOptions.IgnoreCase) >= 0)
            .Select(selector: x => _measuringUnitFactory.Create(measuringUnit: x))
            .ToList();
        }

        public bool Update(MeasuringUnitDTO measuringUnitDTO)
        {
            MeasuringUnit newDomain = _measuringUnitFactory.Create(measuringUnitDTO: measuringUnitDTO);
            MeasuringUnit domain = _measuringUnitRepository.Find(id: measuringUnitDTO.MeasuringUnitId);
         
            domain.MeasuringUnitName = newDomain.MeasuringUnitName;
           

            _measuringUnitRepository.Update(entity: domain);
            _measuringUnitRepository.SaveChanges();

            return true;
        }

        public MeasuringUnitDTO AddNewMeasuringUnit(MeasuringUnitDTO measuringunitDto)
        {
            MeasuringUnit domain = _measuringUnitFactory.Create(measuringUnitDTO: measuringunitDto);

            if (!ValidateDomainModel(u: domain))
            {
                return null;
            }

            var ret = _measuringUnitRepository.Add(entity: domain);
            _measuringUnitRepository.SaveChanges();

            return _measuringUnitFactory.Create(measuringUnit: ret);
        }

        public bool DeleteById(int id)
        {
            var ret = GetById(id: id);
            if (ret == null)
            {
                return false;
            }
            _measuringUnitRepository.Remove(id: id);
            _measuringUnitRepository.SaveChanges();
            return true;
        }

        public MeasuringUnitDTO GetById(int id)
        {
            var measuringUnit = _measuringUnitRepository.Find(id: id);
                return _measuringUnitFactory.Create(measuringUnit: measuringUnit);
            }
        }
    }

