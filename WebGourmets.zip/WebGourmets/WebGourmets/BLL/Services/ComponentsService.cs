﻿
using BLL.DTOs;
using BLL.Factories;
using Domain;
using interfaces;
using Interfaces;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace BLL.Services
{
   public class ComponentsService : Service, IComponentService
    {


            private readonly IComponentRepository _componentRepository;
            private readonly ComponentsFactory _componentsFactory;
            //private readonly ComponentsFactory _componentsFactory;

            public ComponentsService(IComponentRepository componentRepository)
            {
                _componentRepository = componentRepository;
                _componentsFactory = new ComponentsFactory();
                
            }



            private readonly Interfaces.IUow _uow;

            public ComponentsService(IUow uow)
            {
                this._uow = uow;
            }
            public List<ComponentDTO> GetAll()
            {
                return _componentRepository
                .All
                .Select(selector: x => _componentsFactory.Create(component: x))
                .ToList();



            }
            //find component by id
            public ComponentDTO GetById(int id)
            {
                var component = _componentRepository.Find(id: id);
                return _componentsFactory.Create(component: component);
            }

            public List<ComponentDTO> GetComponentByName(string name)
            {
                return _componentRepository
                .All
                .Where(p => CultureInfo.CurrentCulture.CompareInfo.IndexOf(p.ComponentName, name, CompareOptions.IgnoreCase) >= 0)
                .Select(selector: x => _componentsFactory.Create(component: x))
                .ToList();
            }

           

            //add a new component

            public ComponentDTO AddNewComponent(ComponentDTO componentDto)
            {

                Component domain = _componentsFactory.Create(componentDTO: componentDto);

                if (!ValidateDomainModel(u: domain))
                {
                    return null;
                }

                var ret = _componentRepository.Add(entity: domain);
                _componentRepository.SaveChanges();

                return _componentsFactory.Create(component: ret);
            }
            //update a component
            public bool Update(ComponentDTO componentDto)
            {
                Component newDomain = _componentsFactory.Create(componentDTO: componentDto);
                Component domain = _componentRepository.Find(id: componentDto.ComponentId);
            
                domain.ComponentName = newDomain.ComponentName;
                

                _componentRepository.Update(entity: domain);
                _componentRepository.SaveChanges();

                return true;
            }
            //delete a recipe
            public bool DeleteComponentById(int id)
            {
                var ret = GetById(id: id);
                if (ret == null)
                {
                    return false;
                }
                _componentRepository.Remove(id: id);
                _componentRepository.SaveChanges();
                return true;
            }

            public bool DeleteById(int id)
            {
                var ret = GetById(id: id);
                if (ret == null)
                {
                    return false;
                }
                _componentRepository.Remove(id: id);
                _componentRepository.SaveChanges();
                return true;
            }

        }
    }



