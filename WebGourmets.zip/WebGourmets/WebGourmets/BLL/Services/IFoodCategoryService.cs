﻿using BLL.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.Services
{
    public interface IFoodCategoryService: IService
    {
        List<FoodCategoryDTO> GetAll();
        FoodCategoryDTO GetById(int id);
        bool Update(FoodCategoryDTO foodCategoryDto);

        List<FoodCategoryDTO> GetFoodCategoryByName(string name);
        FoodCategoryDTO AddNewFoodCategory(FoodCategoryDTO foodCategoryDto);
        bool DeleteById(int id);
    }
}
