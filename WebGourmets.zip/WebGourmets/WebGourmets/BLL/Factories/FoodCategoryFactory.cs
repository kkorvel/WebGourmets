﻿using BLL.DTOs;
using Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.Factories
{
    class FoodCategoryFactory
    {
        public FoodCategoryDTO Create(FoodCategory foodCategory)
        {
            return new FoodCategoryDTO()
            {
        
                FoodCategoryId = foodCategory.FoodCategoryId,
                FoodCategoryName = foodCategory.FoodCategoryName
            };
        }

        public FoodCategory Create(FoodCategoryDTO foodCategoryDTO)
        {
            return new FoodCategory()
            {

                FoodCategoryId = foodCategoryDTO.FoodCategoryId,
                FoodCategoryName = foodCategoryDTO.FoodCategoryName

            };
        }


    }
}

