﻿using BLL.DTOs;
using Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.Factories
{
   public  class RecipeFactory
    {
        //geti jaoks
        private readonly ComponentsFactory _componentsFactory;
        public RecipeFactory()
        {
            _componentsFactory = new ComponentsFactory();
        }
        public RecipeDTO Create(Recipe recipe)
        {
            return new RecipeDTO()
            {
                RecipeId = recipe.RecipeId,
                RecipeName = recipe.RecipeName,
                FoodCategory = recipe.FoodCategory.FoodCategoryName,


                FoodCategoryId = recipe.FoodCategory.FoodCategoryId,
                RecipeDescription = recipe.RecipeDescription,
                PortionAmount = recipe.PortionAmount,
                Instructions = recipe.Instructions,
                #region
                //ComponentsName = recipe.Component.ComponentName.Select = > _

                //ComponentsName = recipe.Component.ComponentName.Select(z => new ComponentDTO
                //{
                //    ComponentName
                //}).ToList(),
                //ComponentsName = recipe.Component.Select(x => ComponentsFactory.Create(x)).ToList(),

                #endregion
                Components = recipe.RecipeComponent.Select(x => new RecipeComponentsDTO
                {

                    RecipeComponentId = x.RecipeComponentId,
                    RecipeId = x.RecipeId,
                    ComponentId = x.ComponentId,
                    ComponentAmount = x.ComponentAmount,
                    MeasuringUnitId = x.MeasuringUnitId,

                    //oluline
                    ComponentName = x.Component.ComponentName,
                    MeasuringUnitName = x.MeasuringUnit.MeasuringUnitName,
                }).ToList(),
                //Components = recipe.RecipeComponent,
                //FoodCategory = recipe.FoodCategoryId,
                

            };

        }
        // posti jaoks ehk siis create
        public Recipe Create(RecipeDTO recipeDto)
        {
            return new Recipe()
            {
                RecipeId = recipeDto.RecipeId,
                RecipeName = recipeDto.RecipeName,
                RecipeDescription = recipeDto.RecipeDescription,
                PortionAmount = recipeDto.PortionAmount,
                Instructions = recipeDto.Instructions,
                FoodCategoryId = recipeDto.FoodCategoryId,
                ComponentName = recipeDto.ComponentName,
                
            };
        
        }


    }
}
