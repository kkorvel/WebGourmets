﻿using BLL.DTOs;
using Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.Factories
{
   public class MeasuringUnitFactory
    {
        public  MeasuringUnitDTO Create(MeasuringUnit measuringUnit)
        {
            return new MeasuringUnitDTO()
            {
                MeasuringUnitId = measuringUnit.MeasuringUnitId,
                MeasuringUnitName = measuringUnit.MeasuringUnitName,
            };
        }

        public MeasuringUnit Create(MeasuringUnitDTO measuringUnitDTO)
        {
            return new MeasuringUnit()
            {
                MeasuringUnitId = measuringUnitDTO.MeasuringUnitId,
                MeasuringUnitName = measuringUnitDTO.MeasuringUnitName,
            };
        }
    }
}
