﻿using BLL.DTOs;
using Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.Factories
{
    public class ComponentsFactory
    {
        public ComponentDTO Create(Component component)
        {
            return new ComponentDTO()
            {
                ComponentId = component.ComponentId,
                ComponentName = component.ComponentName,
            };
        }

        public Component Create(ComponentDTO componentDTO)
        {
            return new Component()
            {
                ComponentId = componentDTO.ComponentId,
                ComponentName = componentDTO.ComponentName,
            };
        }
    }
}
