﻿using BLL.DTOs;
using Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.Factories
{
    public class RecipeComponentFactory 
    {
        public RecipeComponentsDTO Create(Domain.RecipeComponent recipeComponent)
        {
            return new RecipeComponentsDTO()
            {
                RecipeComponentId = recipeComponent.RecipeComponentId,
                ComponentAmount = recipeComponent.ComponentAmount,
                ComponentId = recipeComponent.ComponentId,
                MeasuringUnitId = recipeComponent.MeasuringUnitId,
                RecipeId = recipeComponent.RecipeId,
                ComponentName = recipeComponent.ComponentName

            };
        }
        public RecipeComponent Create(RecipeComponentsDTO dto)
        {
            return new RecipeComponent()
            {
                RecipeComponentId = dto.RecipeComponentId,
                RecipeId = dto.RecipeId,
                MeasuringUnitId = dto.MeasuringUnitId,
                ComponentAmount = dto.ComponentAmount,
                ComponentId = dto.ComponentId,
                ComponentName = dto.ComponentName

            };
        }
    }
}
