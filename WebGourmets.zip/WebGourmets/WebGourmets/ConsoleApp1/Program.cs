﻿
using ConsoleApp1.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
        
            MainAsync().Wait();
            Console.ReadLine();
        }
        static async Task MainAsync()
        {
          await  DoSimpleGet();
        }
        static async Task DoSimpleGet()
        {
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri("http://localhost:49914/api/");
            var responseMessage = await client.GetAsync("recipe");

            var responseContent = responseMessage.Content.ReadAsStringAsync();
            var responseObject = await responseMessage.Content.ReadAsAsync<List<Recipe>>();

            Console.WriteLine(responseObject);

        }
        static async Task SimplePost()
        {
            HttpClient client = new HttpClient();
            Recipe recipe = new Recipe() { recipeName = "retsepttest", recipeDescription = "hea retsept" };
            client.BaseAddress = new Uri("http://localhost:49914/api/");
            var responseMessage = await client.PostAsJsonAsync("recipe", recipe);
            responseMessage.EnsureSuccessStatusCode();
            //location info
            var stringNewLocation = responseMessage.Headers.Location;
            //var responseContent = responseMessage.Content.ReadAsStringAsync();
            var ret = await responseMessage.Content.ReadAsAsync<Recipe>();
            //Console.WriteLine(responseObject);
        }
        //uuendamiseks
        static async Task SimplePut()
        {
            HttpClient client = new HttpClient();
            Recipe recipe = new Recipe() { recipeName = "retsepttest", recipeDescription = "hea retsept" };
            client.BaseAddress = new Uri("http://localhost:49914/api/");
            var responseMessage = await client.PostAsJsonAsync("recipe", recipe);
            responseMessage.EnsureSuccessStatusCode();
            //location info
            var stringNewLocation = responseMessage.Headers.Location;
            //var responseContent = responseMessage.Content.ReadAsStringAsync();
            var ret = await responseMessage.Content.ReadAsAsync<Recipe>();
            //Console.WriteLine(responseObject);
        }
        //kustutamiseks
        static async Task SimpleDelete(int id)
        {
            HttpClient client = new HttpClient();
            Recipe recipe = new Recipe() { recipeName = "retsepttest", recipeDescription = "hea retsept" };
            client.BaseAddress = new Uri("http://localhost:49914/api/");
            var responseMessage = await client.DeleteAsync("recipe");
            responseMessage.EnsureSuccessStatusCode();
           // var ret = await responseMessage.Content.ReadAsAsync<Recipe>();
        }
    }
}
